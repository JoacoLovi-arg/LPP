library(testthat)
library(rwhatsapp)

test_check("rwhatsapp")
